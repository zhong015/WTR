#import <Foundation/Foundation.h>

@interface HelloWorldIOS : NSObject

- (NSString*)getHelloWorld;

@end
